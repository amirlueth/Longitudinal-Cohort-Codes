scripts <- c(
  "R/00_generate_synthetic_data.R",
  "R/01_build_cohort.R",
  "R/02_define_outcomes.R",
  "R/03_validate_cohort.R",
  "R/04_analysis.R",
  "R/05_sensitivity.R"
)

for (s in scripts) {
  message("\n--- Running ", s, " ---")
  source(s, local = new.env(parent = globalenv()))
}

message("\n--- Running automated tests ---")
testthat::test_dir("tests/testthat")

message("\nPipeline complete. Review files in output/.")
