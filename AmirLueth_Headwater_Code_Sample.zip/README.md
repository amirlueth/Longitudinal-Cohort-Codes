# Headwater Code Sample

## Purpose
This repository demonstrates a reproducible R workflow for constructing and validating a longitudinal, analysis-ready cohort from normalized synthetic EHR-style tables.

The example is intentionally synthetic and does **not** contain NIH, NIEHS, LIFECODES, or other confidential data or code.

## Example question
Among synthetic pregnancy episodes, how is baseline chronic hypertension associated with time to incident preeclampsia after 20 weeks' gestation?

The goal is not to make a clinical or causal claim. The goal is to demonstrate:
- cohort construction from relational data;
- explicit eligibility and time-zero definitions;
- temporal sequencing of baseline, exposure, follow-up, and outcome;
- validation and QC checks;
- reproducible model fitting;
- sensitivity analyses;
- readable code suitable for review.

## Project structure

- `R/00_generate_synthetic_data.R` - creates synthetic source tables
- `R/01_build_cohort.R` - applies eligibility, joins, and cohort logic
- `R/01b_dbplyr_example.R` - optional database-backed `dbplyr`/SQL example
- `R/02_define_outcomes.R` - constructs incident outcome and follow-up
- `R/03_validate_cohort.R` - QC and temporal validation
- `R/04_analysis.R` - descriptive statistics and Cox model
- `R/05_sensitivity.R` - alternative follow-up definition
- `tests/testthat/test_cohort.R` - lightweight automated checks
- `run_all.R` - runs the full pipeline

## Reproducibility
Run from the project root:

```r
source("run_all.R")
```

Required packages:
`dplyr`, `readr`, `tidyr`, `lubridate`, `survival`, `broom`, `testthat` (plus `DBI`, `RSQLite`, and `dbplyr` for the optional SQL example)

## Design choices
- **Time zero:** 20 weeks' gestation.
- **Baseline window:** 180 days before estimated LMP through 19 weeks + 6 days.
- **Exposure:** chronic hypertension documented in the baseline window.
- **Outcome:** first preeclampsia diagnosis on or after 20 weeks and on/before delivery.
- **Censoring:** delivery date.
- **Eligibility:** maternal age 18-45 at LMP, at least two prenatal encounters before time zero, and no preeclampsia before time zero.
- **Validation:** duplicate IDs, impossible dates, outcome-before-index, outcome-after-delivery, and cohort attrition.

## Notes for code review
I would expect production code to use organization-specific code lists, version-controlled phenotype definitions, unit/integration testing, code review, and database-backed workflows (e.g., `dbplyr`/SQL) when working with claims or EHR data at scale.
