library(testthat)
library(readr)
library(dplyr)

test_that("analysis cohort has one row per pregnancy", {
  dat <- read_csv("output/analysis_cohort.csv", show_col_types = FALSE)
  expect_equal(nrow(dat), n_distinct(dat$pregnancy_id))
})

test_that("all outcomes occur during follow-up", {
  dat <- read_csv("output/analysis_cohort.csv", show_col_types = FALSE) %>%
    mutate(across(c(index_date, delivery_date, pe_date), as.Date))
  events <- dat %>% filter(pe_event == 1)
  expect_true(all(events$pe_date >= events$index_date))
  expect_true(all(events$pe_date <= events$delivery_date))
})

test_that("eligibility rules are respected", {
  dat <- read_csv("output/analysis_cohort.csv", show_col_types = FALSE)
  expect_true(all(dat$age_at_lmp >= 18 & dat$age_at_lmp <= 45))
  expect_true(all(dat$n_prenatal_before_index >= 2))
  expect_true(all(dat$early_pe == 0))
})
