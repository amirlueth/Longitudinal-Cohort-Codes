library(dplyr)
library(readr)
library(survival)

dat <- read_csv("output/analysis_cohort.csv", show_col_types = FALSE)

# Sensitivity analysis:
# restrict to pregnancies with >=3 prenatal encounters before time zero.
sens <- dat %>% filter(n_prenatal_before_index >= 3)

fit_sens <- coxph(
  Surv(followup_days, pe_event) ~ baseline_chronic_htn + age_at_lmp,
  data = sens
)

sens_results <- broom::tidy(fit_sens, exponentiate = TRUE, conf.int = TRUE)

write_csv(sens_results, "output/cox_model_results_sensitivity.csv")
print(sens_results)
