library(dplyr)
library(readr)
library(survival)

dat <- read_csv("output/analysis_cohort.csv", show_col_types = FALSE)

descriptive <- dat %>%
  group_by(baseline_chronic_htn) %>%
  summarise(
    n = n(),
    pe_events = sum(pe_event),
    pe_risk_percent = round(100 * mean(pe_event), 1),
    median_followup_days = median(followup_days),
    .groups = "drop"
  )

fit <- coxph(
  Surv(followup_days, pe_event) ~ baseline_chronic_htn + age_at_lmp,
  data = dat
)

model_results <- broom::tidy(fit, exponentiate = TRUE, conf.int = TRUE)

write_csv(descriptive, "output/descriptive_results.csv")
write_csv(model_results, "output/cox_model_results.csv")

print(descriptive)
print(model_results)
