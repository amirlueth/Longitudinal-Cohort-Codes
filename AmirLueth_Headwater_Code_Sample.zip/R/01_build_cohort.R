library(dplyr)
library(readr)
library(lubridate)

patients <- read_csv("data/synthetic/patients.csv", show_col_types = FALSE) %>%
  mutate(dob = as.Date(dob))

pregnancies <- read_csv("data/synthetic/pregnancies.csv", show_col_types = FALSE) %>%
  mutate(across(c(lmp, delivery_date), as.Date))

encounters <- read_csv("data/synthetic/encounters.csv", show_col_types = FALSE) %>%
  mutate(encounter_date = as.Date(encounter_date))

diagnoses <- read_csv("data/synthetic/diagnoses.csv", show_col_types = FALSE) %>%
  mutate(dx_date = as.Date(dx_date))

base <- pregnancies %>%
  left_join(patients, by = "patient_id") %>%
  mutate(
    age_at_lmp = floor(time_length(interval(dob, lmp), "years")),
    index_date = lmp + 140,
    baseline_start = lmp - 180,
    baseline_end = index_date - 1
  )

prenatal_counts <- encounters %>%
  inner_join(base %>% select(pregnancy_id, lmp, index_date), by = "pregnancy_id") %>%
  filter(
    encounter_type == "prenatal",
    encounter_date >= lmp,
    encounter_date < index_date
  ) %>%
  count(pregnancy_id, name = "n_prenatal_before_index")

baseline_htn <- diagnoses %>%
  inner_join(base %>% select(pregnancy_id, baseline_start, baseline_end), by = "pregnancy_id") %>%
  filter(
    dx_code == "I10",
    dx_date >= baseline_start,
    dx_date <= baseline_end
  ) %>%
  distinct(pregnancy_id) %>%
  mutate(baseline_chronic_htn = 1L)

early_pe <- diagnoses %>%
  inner_join(base %>% select(pregnancy_id, index_date), by = "pregnancy_id") %>%
  filter(dx_code == "O14", dx_date < index_date) %>%
  distinct(pregnancy_id) %>%
  mutate(early_pe = 1L)

cohort_pre <- base %>%
  left_join(prenatal_counts, by = "pregnancy_id") %>%
  left_join(baseline_htn, by = "pregnancy_id") %>%
  left_join(early_pe, by = "pregnancy_id") %>%
  mutate(
    n_prenatal_before_index = coalesce(n_prenatal_before_index, 0L),
    baseline_chronic_htn = coalesce(baseline_chronic_htn, 0L),
    early_pe = coalesce(early_pe, 0L),
    eligible_age = between(age_at_lmp, 18, 45),
    eligible_prenatal = n_prenatal_before_index >= 2,
    eligible_no_early_pe = early_pe == 0
  )

cohort <- cohort_pre %>%
  filter(eligible_age, eligible_prenatal, eligible_no_early_pe)

dir.create("output", showWarnings = FALSE)
write_csv(cohort_pre, "output/cohort_with_eligibility_flags.csv")
write_csv(cohort, "output/cohort_eligible.csv")

message("Eligible cohort built: ", nrow(cohort), " pregnancy episodes.")
