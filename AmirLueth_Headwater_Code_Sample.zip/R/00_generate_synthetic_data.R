library(dplyr)
library(readr)
library(lubridate)
library(tidyr)

set.seed(3456)

dir.create("data/synthetic", recursive = TRUE, showWarnings = FALSE)

n <- 1200

patients <- tibble(
  patient_id = sprintf("P%05d", 1:n),
  dob = as.Date("1978-01-01") + sample(0:8000, n, replace = TRUE)
)

pregnancies <- tibble(
  pregnancy_id = sprintf("G%05d", 1:n),
  patient_id = patients$patient_id,
  lmp = as.Date("2023-01-01") + sample(0:500, n, replace = TRUE),
  gest_days = pmin(pmax(round(rnorm(n, 274, 12)), 220), 294)
) %>%
  mutate(delivery_date = lmp + gest_days)

# Re-anchor implausible ages so the source data contain mostly eligible patients
# with a small number of records near eligibility boundaries.
patients <- patients %>%
  left_join(pregnancies %>% select(patient_id, lmp), by = "patient_id") %>%
  mutate(
    age_at_lmp = floor(time_length(interval(dob, lmp), "years")),
    dob = if_else(
      age_at_lmp < 15 | age_at_lmp > 50,
      lmp - years(sample(17:46, n(), replace = TRUE)),
      dob
    )
  ) %>%
  select(patient_id, dob)

# Baseline chronic hypertension prevalence ~12%.
chronic_htn_tbl <- pregnancies %>%
  select(pregnancy_id, patient_id, lmp, delivery_date, gest_days) %>%
  mutate(chronic_htn = rbinom(n(), 1, 0.12))

# Preeclampsia probability is higher among those with baseline chronic HTN.
event_tbl <- chronic_htn_tbl %>%
  mutate(
    pe_prob = plogis(-2.7 + 1.15 * chronic_htn),
    pe_event = rbinom(n(), 1, pe_prob)
  )

encounters <- pregnancies %>%
  rowwise() %>%
  do({
    g <- .
    k <- sample(3:9, 1)
    dates <- sort(g$lmp + sample(20:(g$gest_days - 2), k))
    tibble(
      encounter_id = paste0(g$pregnancy_id, "_E", seq_along(dates)),
      patient_id = g$patient_id,
      pregnancy_id = g$pregnancy_id,
      encounter_date = dates,
      encounter_type = sample(
        c("prenatal", "prenatal", "prenatal", "urgent"),
        k,
        replace = TRUE
      )
    )
  }) %>%
  ungroup()

chronic_dx <- chronic_htn_tbl %>%
  filter(chronic_htn == 1) %>%
  rowwise() %>%
  mutate(dx_date = lmp - sample(10:150, 1)) %>%
  ungroup() %>%
  transmute(
    patient_id,
    pregnancy_id,
    dx_date,
    dx_code = "I10",
    dx_label = "Chronic hypertension"
  )

pe_dx <- event_tbl %>%
  filter(pe_event == 1) %>%
  rowwise() %>%
  mutate(
    # Incident PE is generated at/after 20 weeks and no later than delivery.
    max_day = min(gest_days, 280),
    dx_day = sample(140:max_day, 1),
    dx_date = lmp + dx_day
  ) %>%
  ungroup() %>%
  transmute(
    patient_id,
    pregnancy_id,
    dx_date,
    dx_code = "O14",
    dx_label = "Preeclampsia"
  )

# Add a small number of intentionally early PE records so the cohort-building
# code must exclude prevalent/early outcomes before time zero.
early_idx <- sample(seq_len(n), 15)
early_pe <- pregnancies[early_idx, ] %>%
  rowwise() %>%
  mutate(dx_date = lmp + sample(90:130, 1)) %>%
  ungroup() %>%
  transmute(
    patient_id,
    pregnancy_id,
    dx_date,
    dx_code = "O14",
    dx_label = "Preeclampsia"
  )

diagnoses <- bind_rows(chronic_dx, pe_dx, early_pe) %>%
  arrange(patient_id, dx_date)

vitals <- pregnancies %>%
  rowwise() %>%
  do({
    g <- .
    k <- sample(4:10, 1)
    dates <- sort(g$lmp + sample(35:(g$gest_days - 1), k))
    base_sbp <- rnorm(1, 116, 8)
    tibble(
      patient_id = g$patient_id,
      pregnancy_id = g$pregnancy_id,
      vital_date = dates,
      sbp = round(base_sbp + 0.035 * as.numeric(dates - g$lmp) + rnorm(k, 0, 7)),
      dbp = round(72 + 0.02 * as.numeric(dates - g$lmp) + rnorm(k, 0, 5))
    )
  }) %>%
  ungroup()

write_csv(patients, "data/synthetic/patients.csv")
write_csv(pregnancies, "data/synthetic/pregnancies.csv")
write_csv(encounters, "data/synthetic/encounters.csv")
write_csv(diagnoses, "data/synthetic/diagnoses.csv")
write_csv(vitals, "data/synthetic/vitals.csv")

message("Synthetic source tables created.")
