library(dplyr)
library(readr)

cohort <- read_csv("output/cohort_eligible.csv", show_col_types = FALSE) %>%
  mutate(across(c(lmp, delivery_date, index_date, baseline_start, baseline_end), as.Date))

diagnoses <- read_csv("data/synthetic/diagnoses.csv", show_col_types = FALSE) %>%
  mutate(dx_date = as.Date(dx_date))

incident_pe <- diagnoses %>%
  inner_join(
    cohort %>% select(pregnancy_id, index_date, delivery_date),
    by = "pregnancy_id"
  ) %>%
  filter(
    dx_code == "O14",
    dx_date >= index_date,
    dx_date <= delivery_date
  ) %>%
  group_by(pregnancy_id) %>%
  summarise(pe_date = min(dx_date), .groups = "drop")

analysis_cohort <- cohort %>%
  left_join(incident_pe, by = "pregnancy_id") %>%
  mutate(
    pe_event = as.integer(!is.na(pe_date)),
    end_date = if_else(pe_event == 1L, pe_date, delivery_date),
    followup_days = as.integer(end_date - index_date)
  )

write_csv(analysis_cohort, "output/analysis_cohort.csv")
message("Outcome defined. Incident PE events: ", sum(analysis_cohort$pe_event))
