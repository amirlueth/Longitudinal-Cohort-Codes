library(dplyr)
library(readr)

cohort_pre <- read_csv("output/cohort_with_eligibility_flags.csv", show_col_types = FALSE)
cohort <- read_csv("output/analysis_cohort.csv", show_col_types = FALSE) %>%
  mutate(across(c(lmp, delivery_date, index_date, pe_date, end_date), as.Date))

qc <- tibble(
  check = c(
    "Unique pregnancy_id",
    "Index before delivery",
    "Nonnegative follow-up",
    "Outcome not before index",
    "Outcome not after delivery",
    "Eligible age only",
    "At least 2 prenatal visits"
  ),
  failures = c(
    sum(duplicated(cohort$pregnancy_id)),
    sum(cohort$index_date > cohort$delivery_date, na.rm = TRUE),
    sum(cohort$followup_days < 0, na.rm = TRUE),
    sum(cohort$pe_event == 1 & cohort$pe_date < cohort$index_date, na.rm = TRUE),
    sum(cohort$pe_event == 1 & cohort$pe_date > cohort$delivery_date, na.rm = TRUE),
    sum(!between(cohort$age_at_lmp, 18, 45), na.rm = TRUE),
    sum(cohort$n_prenatal_before_index < 2, na.rm = TRUE)
  )
)

attrition <- tibble(
  step = c(
    "All pregnancy episodes",
    "Age 18-45",
    "At least 2 prenatal encounters before index",
    "No preeclampsia before index",
    "Final eligible cohort"
  ),
  n = c(
    nrow(cohort_pre),
    sum(cohort_pre$eligible_age),
    sum(cohort_pre$eligible_age & cohort_pre$eligible_prenatal),
    sum(cohort_pre$eligible_age & cohort_pre$eligible_prenatal & cohort_pre$eligible_no_early_pe),
    nrow(cohort)
  )
)

write_csv(qc, "output/qc_checks.csv")
write_csv(attrition, "output/cohort_attrition.csv")

print(qc)
print(attrition)

stopifnot(all(qc$failures == 0))
message("All QC checks passed.")
